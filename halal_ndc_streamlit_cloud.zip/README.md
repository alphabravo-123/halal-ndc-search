# NDC Halal Search

Deployed on Streamlit Cloud.
